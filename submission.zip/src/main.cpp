#include "executor.h"

/**
 * @brief Start point for program
 * @return: 0 for success
 */
int main() {
    run();
    return 0;
}
